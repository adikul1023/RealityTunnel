-- RealityTunnel Database Snapshot — 2026-07-19T06:50:21.673424+00:00

-- TABLE: alembic_version
{"table": "alembic_version", "row": {"version_num": "16a49510ad7c"}}

-- TABLE: payments

-- TABLE: accounts

-- TABLE: system_health_status
{"table": "system_health_status", "row": {"component_key": "marzban", "status": "degraded", "message": "Marzban API health check failed", "last_checked_at": "2026-07-19T06:46:53.229532+00:00", "created_at": "2026-07-13T11:39:17.987736+00:00", "updated_at": "2026-07-19T06:46:54.795318+00:00"}}
{"table": "system_health_status", "row": {"component_key": "payment_gateway", "status": "degraded", "message": "Payment Gateway health check failed", "last_checked_at": "2026-07-19T06:46:53.229532+00:00", "created_at": "2026-07-13T11:39:17.998923+00:00", "updated_at": "2026-07-19T06:46:54.813977+00:00"}}

-- TABLE: provisioning_profiles

-- TABLE: provisioning_retry_queue

-- TABLE: devices

-- TABLE: exchange_tokens

-- TABLE: connection_signals

-- TABLE: audit_events
{"table": "audit_events", "row": {"event_id": "446a6451-6154-4ccb-8850-cd5e8f7b66ec", "timestamp": "2026-07-19T06:10:18.035405+00:00", "event_type": "admin_login", "actor_id": "ebf65e38-1f87-4fa2-8a96-76dad86c5176", "target_id": "system", "details": "{'action': 'login_success', 'username': 'test_admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:10:18.035405+00:00", "updated_at": "2026-07-19T06:10:18.035405+00:00"}}
{"table": "audit_events", "row": {"event_id": "c3ec6040-9786-4d79-a1b8-711b1d110906", "timestamp": "2026-07-19T06:27:24.725365+00:00", "event_type": "admin_login", "actor_id": "admin", "target_id": "system", "details": "{'action': 'login_attempt', 'status': 'failed', 'reason': 'invalid_credentials'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:27:24.725365+00:00", "updated_at": "2026-07-19T06:27:24.725365+00:00"}}
{"table": "audit_events", "row": {"event_id": "03bf935c-3345-4a4b-9cea-e1910aa55451", "timestamp": "2026-07-19T06:28:59.534017+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:28:59.534017+00:00", "updated_at": "2026-07-19T06:28:59.534017+00:00"}}
{"table": "audit_events", "row": {"event_id": "9f2eea11-26a4-44f6-8601-04d12eb5d58e", "timestamp": "2026-07-19T06:29:39.865657+00:00", "event_type": "admin_login", "actor_id": "admin", "target_id": "system", "details": "{'action': 'login_attempt', 'status': 'failed', 'reason': 'invalid_credentials'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:29:39.865657+00:00", "updated_at": "2026-07-19T06:29:39.865657+00:00"}}
{"table": "audit_events", "row": {"event_id": "303ab070-eb4c-4244-bf31-51b59678f4e1", "timestamp": "2026-07-19T06:30:05.619141+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:30:05.619141+00:00", "updated_at": "2026-07-19T06:30:05.619141+00:00"}}
{"table": "audit_events", "row": {"event_id": "31ef54a2-20ad-41ca-83ff-23d186f1862d", "timestamp": "2026-07-19T06:31:59.987703+00:00", "event_type": "admin_login", "actor_id": "admin", "target_id": "system", "details": "{'action': 'login_attempt', 'status': 'failed', 'reason': 'invalid_credentials'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:31:59.987703+00:00", "updated_at": "2026-07-19T06:31:59.987703+00:00"}}
{"table": "audit_events", "row": {"event_id": "1a7e64ba-465d-4448-bc4d-1bde63f41cad", "timestamp": "2026-07-19T06:32:32.760212+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:32:32.760212+00:00", "updated_at": "2026-07-19T06:32:32.760212+00:00"}}
{"table": "audit_events", "row": {"event_id": "276ab8a0-838d-4746-b324-1ca0c8981c85", "timestamp": "2026-07-19T06:32:32.945597+00:00", "event_type": "admin_action", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "details": "{'action': 'ADMIN_PASSWORD_CHANGED', 'username': 'admin'}", "ip_hash": "0000000000000000", "created_at": "2026-07-19T06:32:32.945597+00:00", "updated_at": "2026-07-19T06:32:32.945597+00:00"}}
{"table": "audit_events", "row": {"event_id": "c4026ebe-0508-46d5-957c-30df7e47c141", "timestamp": "2026-07-19T06:32:33.133564+00:00", "event_type": "admin_action", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "details": "{'action': 'ADMIN_PASSWORD_CHANGED', 'username': 'admin'}", "ip_hash": "0000000000000000", "created_at": "2026-07-19T06:32:33.133564+00:00", "updated_at": "2026-07-19T06:32:33.133564+00:00"}}
{"table": "audit_events", "row": {"event_id": "3c521760-b56f-4868-a843-c3b7a227447c", "timestamp": "2026-07-19T06:37:41.784765+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:37:41.784765+00:00", "updated_at": "2026-07-19T06:37:41.784765+00:00"}}
{"table": "audit_events", "row": {"event_id": "90179de4-8718-4c1a-bb82-0509d8f92735", "timestamp": "2026-07-19T06:40:26.098917+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:40:26.098917+00:00", "updated_at": "2026-07-19T06:40:26.098917+00:00"}}
{"table": "audit_events", "row": {"event_id": "747d6f44-b7e4-4b18-8fa6-47649eb586e0", "timestamp": "2026-07-19T06:44:55.903738+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:44:55.903738+00:00", "updated_at": "2026-07-19T06:44:55.903738+00:00"}}
{"table": "audit_events", "row": {"event_id": "040a9f39-a8f3-4d20-86dd-c30f2d2afbe5", "timestamp": "2026-07-19T06:45:53.155689+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:45:53.155689+00:00", "updated_at": "2026-07-19T06:45:53.155689+00:00"}}
{"table": "audit_events", "row": {"event_id": "175553ea-58ba-47c8-bba3-b46238abec4e", "timestamp": "2026-07-19T06:48:40.402265+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:48:40.402265+00:00", "updated_at": "2026-07-19T06:48:40.402265+00:00"}}
{"table": "audit_events", "row": {"event_id": "a6db3538-7887-4918-97c8-2b65630945c6", "timestamp": "2026-07-19T06:50:01.544643+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:50:01.544643+00:00", "updated_at": "2026-07-19T06:50:01.544643+00:00"}}
{"table": "audit_events", "row": {"event_id": "74e2759c-b020-4697-82e0-b1fd30662cc5", "timestamp": "2026-07-19T06:50:21.602511+00:00", "event_type": "admin_login", "actor_id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "target_id": "system", "details": "{'action': 'login_success', 'username': 'admin', 'role': 'super_admin'}", "ip_hash": "12ca17b49af22894", "created_at": "2026-07-19T06:50:21.602511+00:00", "updated_at": "2026-07-19T06:50:21.602511+00:00"}}

-- TABLE: subscriptions

-- TABLE: refresh_tokens

-- TABLE: admin_users
{"table": "admin_users", "row": {"id": "0fa23e2f-0372-4ebe-90c2-dab9243fac1b", "username": "admin", "password_hash": "$argon2id$v=19$m=65536,t=3,p=4$nqFztp6ED8AXmJYS7wloPA$clQQBjWwMvNkeiZHbqDrhC+w6lYU4ixLvEMUdY915wg", "is_active": true, "is_super_admin": true, "mfa_enabled": false, "last_login_at": "2026-07-19T06:50:21.590363+00:00", "created_at": "2026-07-19T06:28:32.078287+00:00", "updated_at": "2026-07-19T06:50:21.519159+00:00"}}
