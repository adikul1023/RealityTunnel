"""
devices.py — Device Management API Endpoints Router (Phase 1.4.2).

Thin orchestration layer connecting HTTP requests to domain DeviceService.
Strictly decoupled from business logic, validation logic, and direct database queries.

Endpoints:
  - GET    /api/devices
  - GET    /api/devices/{device_guid}
  - PATCH  /api/devices/{device_guid}
  - DELETE /api/devices/{device_guid}
  - POST   /api/devices/{device_guid}/reactivate

LOGGING INVARIANT:
Never logs Account IDs, database UUIDs, or Device GUIDs.
Logs only generic outcome descriptions: "List devices succeeded", "Get device succeeded",
"Rename device succeeded", "Deactivate device succeeded", "Reactivate device succeeded".
"""
from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Header, Request, status

from app.dependencies import get_current_account, get_device_service, get_signal_service
from app.models.account import Account
from app.models.connection_signal import ConnectionEventType
from app.rate_limit import require_rate_limit
from app.services import DeviceService, ConnectionSignalService
from app.services.exceptions import InactiveDeviceError
from app.security_hardening.audit import audit_service
from app.observability.logging import extract_client_info
from app.routers.device_models import (
    DeviceListResponse,
    DeviceResponse,
    DeviceStatusResponse,
    RegisterDeviceRequest,
    RenameDeviceRequest,
    SuccessResponse,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/devices", tags=["Devices"])


async def safe_record_signal(
    signal_service: ConnectionSignalService,
    account_id: uuid.UUID | None,
    event_type: ConnectionEventType,
    success: bool,
    device_guid: str | None = None,
    http_request: Request | None = None,
) -> None:
    """Safely record a security signal without letting exceptions disrupt device management."""
    try:
        source_ip = getattr(http_request.state, "client_ip", "unknown") if http_request else None
        user_agent = http_request.headers.get("user-agent") if http_request else None
        await signal_service.record_signal(
            account_id=account_id,
            event_type=event_type,
            success=success,
            device_guid=device_guid,
            source_ip=source_ip,
            user_agent=user_agent,
        )
    except Exception as exc:
        logger.error("Failed to record connection signal: %s", exc)


@router.post(
    "",
    summary="Register a client device under the authenticated account",
    response_model=DeviceResponse,
    status_code=status.HTTP_200_OK,
    dependencies=[Depends(require_rate_limit("device_register"))],
    responses={
        400: {"description": "Validation error"},
        401: {"description": "Authentication failed or token invalid"},
        403: {"description": "Device limit reached for subscription plan"},
        429: {"description": "Rate limit exceeded"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def register_device(
    request: RegisterDeviceRequest,
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    signal_service: ConnectionSignalService = Depends(get_signal_service),
) -> DeviceResponse:
    """Register a client device or update its timestamps if already registered."""
    try:
        device = await device_service.register_device(
            current_account.id,
            request.device_guid,
            request.friendly_name,
        )
    except Exception:
        logger.info("Register device failed")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_REGISTER,
            success=False,
            device_guid=request.device_guid,
            http_request=http_request,
        )
        raise

    logger.info("Register device succeeded")
    await safe_record_signal(
        signal_service,
        account_id=current_account.id,
        event_type=ConnectionEventType.DEVICE_REGISTER,
        success=True,
        device_guid=request.device_guid,
        http_request=http_request,
    )
    await audit_service.record_event(
        event_type="device_register",
        actor_id=str(current_account.id),
        target_id=request.device_guid,
        details={"action": "register_device", "friendly_name": request.friendly_name},
    )
    return DeviceResponse.model_validate(device)


@router.get(
    "",
    summary="List all registered client devices for current account",
    response_model=DeviceListResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"description": "Authentication failed or token invalid"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def list_devices(
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
) -> DeviceListResponse:
    """Return all client devices owned by the authenticated account."""
    devices = await device_service.get_devices_for_account(current_account.id)
    logger.info("List devices succeeded")
    return DeviceListResponse(
        devices=[DeviceResponse.model_validate(d) for d in devices]
    )


@router.get(
    "/status",
    summary="Check real-time device presence and active status",
    response_model=DeviceStatusResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"description": "Authentication failed or token invalid"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def check_device_status(
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    x_device_guid: str | None = Header(default=None, alias="X-Device-Guid"),
    device_guid: str | None = None,
) -> DeviceStatusResponse:
    """
    Lightweight heartbeat endpoint reporting device active status.
    Scopes device check strictly to current authenticated account.
    Returns 200 OK with active=false when device is removed or inactive.
    """
    guid = x_device_guid or device_guid
    now = datetime.now(timezone.utc)
    if not guid:
        return DeviceStatusResponse(
            active=False,
            reason="DEVICE_REMOVED",
            server_time=now,
            heartbeat_interval=60,
            heartbeat_jitter=10,
        )
    active, reason = await device_service.get_device_status(current_account.id, guid)
    logger.info(
        "Heartbeat check",
        extra={
            "account_id": current_account.account_id,
            "device_guid": guid,
            "action": "HEARTBEAT",
            "status": "ACTIVE" if active else "REMOVED",
            **extract_client_info(http_request),
        },
    )
    return DeviceStatusResponse(
        active=active,
        reason=reason,
        server_time=now,
        heartbeat_interval=60,
        heartbeat_jitter=10,
    )


@router.get(
    "/{device_guid}",
    summary="Retrieve details for a specific registered device",
    response_model=DeviceResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"description": "Authentication failed or token invalid"},
        404: {"description": "Device not found or owned by another account"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def get_device(
    device_guid: str,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
) -> DeviceResponse:
    """Retrieve exactly one device. Returns 404 if device is missing or belongs to another account."""
    device = await device_service.get_device(current_account.id, device_guid)
    logger.info("Get device succeeded")
    return DeviceResponse.model_validate(device)


@router.patch(
    "/{device_guid}",
    summary="Update friendly name for a specific registered device",
    response_model=DeviceResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"description": "Validation error or device inactive"},
        401: {"description": "Authentication failed or token invalid"},
        404: {"description": "Device not found or owned by another account"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def rename_device(
    device_guid: str,
    request: RenameDeviceRequest,
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    signal_service: ConnectionSignalService = Depends(get_signal_service),
) -> DeviceResponse:
    """Update friendly name of an active device. Rejects updates if device is inactive."""
    try:
        device = await device_service.rename_device(
            current_account.id, device_guid, request.friendly_name
        )
    except Exception:
        logger.info("Rename device failed")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_RENAME,
            success=False,
            device_guid=device_guid,
            http_request=http_request,
        )
        raise

    logger.info("Rename device succeeded")
    await safe_record_signal(
        signal_service,
        account_id=current_account.id,
        event_type=ConnectionEventType.DEVICE_RENAME,
        success=True,
        device_guid=device_guid,
        http_request=http_request,
    )
    return DeviceResponse.model_validate(device)


@router.delete(
    "/{device_guid}",
    summary="Soft-deactivate a registered client device",
    response_model=SuccessResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"description": "Authentication failed or token invalid"},
        404: {"description": "Device not found or owned by another account"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def deactivate_device(
    device_guid: str,
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    signal_service: ConnectionSignalService = Depends(get_signal_service),
) -> SuccessResponse:
    """Soft-deactivate a device by setting is_active to False. Operation is idempotent."""
    try:
        await device_service.deactivate_device(current_account.id, device_guid)
    except InactiveDeviceError:
        logger.info("Deactivate device succeeded (already inactive)")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_DEACTIVATE,
            success=True,
            device_guid=device_guid,
            http_request=http_request,
        )
        await audit_service.record_event(
            event_type="device_deactivate",
            actor_id=str(current_account.id),
            target_id=device_guid,
            details={"action": "deactivate_device", "status": "already_inactive"},
        )
        return SuccessResponse(success=True, message="Device deactivated successfully")
    except Exception:
        logger.info("Deactivate device failed")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_DEACTIVATE,
            success=False,
            device_guid=device_guid,
            http_request=http_request,
        )
        raise

    logger.info("Deactivate device succeeded")
    await safe_record_signal(
        signal_service,
        account_id=current_account.id,
        event_type=ConnectionEventType.DEVICE_DEACTIVATE,
        success=True,
        device_guid=device_guid,
        http_request=http_request,
    )
    await audit_service.record_event(
        event_type="device_deactivate",
        actor_id=str(current_account.id),
        target_id=device_guid,
        details={"action": "deactivate_device"},
    )
    return SuccessResponse(success=True, message="Device deactivated successfully")


@router.post(
    "/{device_guid}/suspend",
    summary="Soft-deactivate a registered client device",
    response_model=SuccessResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"description": "Authentication failed or token invalid"},
        404: {"description": "Device not found or owned by another account"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def suspend_device(
    device_guid: str,
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    signal_service: ConnectionSignalService = Depends(get_signal_service),
) -> SuccessResponse:
    """Soft-delete a device by setting is_active to False. Operation is idempotent."""
    try:
        await device_service.suspend_device(current_account.id, device_guid)
    except InactiveDeviceError:
        logger.info("Suspend device succeeded (already inactive)")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_DEACTIVATE,
            success=True,
            device_guid=device_guid,
            http_request=http_request,
        )
        await audit_service.record_event(
            event_type="device_suspend",
            actor_id=str(current_account.id),
            target_id=device_guid,
            details={"action": "suspend_device", "status": "already_inactive"},
        )
        return SuccessResponse(success=True, message="Device suspended successfully")
    except Exception:
        logger.info("Suspend device failed")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_DEACTIVATE,
            success=False,
            device_guid=device_guid,
            http_request=http_request,
        )
        raise

    logger.info("Suspend device succeeded")
    await safe_record_signal(
        signal_service,
        account_id=current_account.id,
        event_type=ConnectionEventType.DEVICE_DEACTIVATE,
        success=True,
        device_guid=device_guid,
        http_request=http_request,
    )
    await audit_service.record_event(
        event_type="device_suspend",
        actor_id=str(current_account.id),
        target_id=device_guid,
        details={"action": "suspend_device"},
    )
    return SuccessResponse(success=True, message="Device suspended successfully")


@router.post(
    "/{device_guid}/reactivate",
    summary="Reactivate a soft-deactivated client device",
    response_model=DeviceResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"description": "Validation error or device already active"},
        401: {"description": "Authentication failed or token invalid"},
        404: {"description": "Device not found or owned by another account"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def reactivate_device(
    device_guid: str,
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    signal_service: ConnectionSignalService = Depends(get_signal_service),
) -> DeviceResponse:
    """Reactivate a previously deactivated device."""
    try:
        device = await device_service.reactivate_device(current_account.id, device_guid)
    except InactiveDeviceError:
        logger.info("Reactivate device succeeded (already active)")
        device = await device_service.get_device(current_account.id, device_guid)
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_REACTIVATE,
            success=True,
            device_guid=device_guid,
            http_request=http_request,
        )
        await audit_service.record_event(
            event_type="device_reactivate",
            actor_id=str(current_account.id),
            target_id=device_guid,
            details={"action": "reactivate_device", "status": "already_active"},
        )
        return DeviceResponse.model_validate(device)
    except Exception:
        logger.info("Reactivate device failed")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_REACTIVATE,
            success=False,
            device_guid=device_guid,
            http_request=http_request,
        )
        raise

    logger.info("Reactivate device succeeded")
    await safe_record_signal(
        signal_service,
        account_id=current_account.id,
        event_type=ConnectionEventType.DEVICE_REACTIVATE,
        success=True,
        device_guid=device_guid,
        http_request=http_request,
    )
    await audit_service.record_event(
        event_type="device_reactivate",
        actor_id=str(current_account.id),
        target_id=device_guid,
        details={"action": "reactivate_device"},
    )
    return DeviceResponse.model_validate(device)


@router.delete(
    "/id/{device_id}",
    summary="Permanently delete/unbind a device by its database ID",
    response_model=SuccessResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"description": "Authentication failed or token invalid"},
        404: {"description": "Device not found or owned by another account"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def delete_device_by_id(
    device_id: uuid.UUID,
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    signal_service: ConnectionSignalService = Depends(get_signal_service),
) -> SuccessResponse:
    """Permanently delete a device record from the account."""
    try:
        await device_service.delete_device(current_account.id, device_id)
    except Exception:
        logger.info("Delete device failed")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_DELETE,
            success=False,
            device_guid=str(device_id),
            http_request=http_request,
        )
        raise

    logger.info("Delete device succeeded")
    await safe_record_signal(
        signal_service,
        account_id=current_account.id,
        event_type=ConnectionEventType.DEVICE_DELETE,
        success=True,
        device_guid=str(device_id),
        http_request=http_request,
    )
    await audit_service.record_event(
        event_type="device_delete",
        actor_id=str(current_account.id),
        target_id=str(device_id),
        details={"action": "delete_device"},
    )
    return SuccessResponse(success=True, message="Device deleted successfully")


@router.delete(
    "/{device_guid}/unbind",
    summary="Permanently delete/unbind a device by its GUID",
    response_model=SuccessResponse,
    status_code=status.HTTP_200_OK,
    responses={
        401: {"description": "Authentication failed or token invalid"},
        404: {"description": "Device not found or owned by another account"},
        500: {"description": "Unexpected service or database error"},
    },
)
async def unbind_device_by_guid(
    device_guid: str,
    http_request: Request,
    current_account: Account = Depends(get_current_account),
    device_service: DeviceService = Depends(get_device_service),
    signal_service: ConnectionSignalService = Depends(get_signal_service),
) -> SuccessResponse:
    """Permanently delete a device record by device GUID."""
    try:
        await device_service.delete_device_by_guid(current_account.id, device_guid)
    except Exception:
        logger.info("Unbind device failed")
        await safe_record_signal(
            signal_service,
            account_id=current_account.id,
            event_type=ConnectionEventType.DEVICE_DELETE,
            success=False,
            device_guid=device_guid,
            http_request=http_request,
        )
        raise

    logger.info("Unbind device succeeded")
    await safe_record_signal(
        signal_service,
        account_id=current_account.id,
        event_type=ConnectionEventType.DEVICE_DELETE,
        success=True,
        device_guid=device_guid,
        http_request=http_request,
    )
    await audit_service.record_event(
        event_type="device_delete",
        actor_id=str(current_account.id),
        target_id=device_guid,
        details={"action": "unbind_device"},
    )
    return SuccessResponse(success=True, message="Device unbound successfully")
