"""
service.py — PaymentService orchestrating payment transactions, gateway interactions,
and entitlement activation via SubscriptionService (Phase 2.3).
"""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timedelta, timezone

from sqlalchemy.ext.asyncio import AsyncSession

from app.exceptions import EntityNotFoundError, DuplicateEntityError
from app.database import advisory_xact_lock
from app.models import Payment, PaymentProviderType, PaymentStatus
from app.models.base import SubscriptionLifecycleStatus
from app.repositories import PaymentRepository, SubscriptionRepository
from app.services.exceptions import (
    DuplicateWebhookError,
    PaymentNotFoundError,
    PaymentRefundError,
    PaymentServiceError,
    PaymentVerificationError,
    PaymentWebhookError,
    ProvisioningConflictError,
)
from app.services.payment.provider import PaymentProvider
from app.services.subscription_service import SubscriptionService

logger = logging.getLogger(__name__)


class PaymentService:
    """
    Orchestration service for payment lifecycle, webhook verification, and entitlement updates.
    Strictly decoupled from VPN provisioning: all entitlement changes flow through SubscriptionService.
    Never communicates with ProvisioningService or Marzban directly.
    """

    def __init__(
        self,
        session: AsyncSession,
        provider: PaymentProvider,
        subscription_service: SubscriptionService | None = None,
    ) -> None:
        self.session = session
        self.provider = provider
        self.payment_repo = PaymentRepository(session)
        self.subscription_repo = SubscriptionRepository(session)
        self.subscription_service = subscription_service or SubscriptionService(session)

    async def create_payment(
        self,
        account_id: uuid.UUID,
        amount_minor_units: int,
        currency: str,
        idempotency_key: str,
        plan_id: str = "pro",
        subscription_id: uuid.UUID | None = None,
    ) -> Payment:
        """
        Create a new payment transaction and initiate an order on the payment gateway.
        Idempotent: if idempotency_key already exists, returns the existing payment record.
        """
        await advisory_xact_lock(self.session, f"payment_idempotency:{idempotency_key}")

        existing = await self.payment_repo.get_by_idempotency_key(
            idempotency_key, for_update=True
        )
        if existing:
            logger.info(
                "Returning existing payment id=%s for idempotency_key=%s",
                existing.id,
                idempotency_key,
            )
            return existing

        receipt = f"rcpt_{idempotency_key[:24]}"
        notes = {
            "account_id": str(account_id),
            "plan_id": plan_id,
        }
        if subscription_id:
            notes["subscription_id"] = str(subscription_id)

        order_dto = await self.provider.create_order(
            amount_minor_units=amount_minor_units,
            currency=currency,
            receipt=receipt,
            notes=notes,
        )

        try:
            payment = await self.payment_repo.create(
                account_id=account_id,
                subscription_id=subscription_id,
                provider=PaymentProviderType.RAZORPAY,
                provider_order_id=order_dto.provider_order_id,
                amount_minor_units=order_dto.amount_minor_units,
                currency=order_dto.currency,
                status=PaymentStatus.CREATED,
                idempotency_key=idempotency_key,
            )
        except DuplicateEntityError:
            # Race recovery (Finding M-1): loser of the idempotency_key unique-index race
            # re-fetches the winner's row instead of surfacing a raw 500.
            existing = await self.payment_repo.get_by_idempotency_key(
                idempotency_key, for_update=True
            )
            if existing:
                logger.info(
                    "Returning existing payment id=%s after idempotency race for key=%s",
                    existing.id,
                    idempotency_key,
                )
                return existing
            raise
        logger.info(
            "Created new payment id=%s order_id=%s status=%s",
            payment.id,
            payment.provider_order_id,
            payment.status.value,
        )
        return payment

    async def confirm_payment(
        self,
        provider_order_id: str,
        provider_payment_id: str,
        signature: str | None = None,
        raw_payload: bytes | str | None = None,
        plan_id: str = "standard",
    ) -> Payment:
        """
        Confirm a payment upon gateway webhook or redirect verification.
        Must:
        1. Verify webhook signature (if provided).
        2. Verify provider payment status via fetch_payment.
        3. Verify idempotency using row lock (for_update=True).
        4. Persist payment state to PAID.
        5. Activate or renew subscription via SubscriptionService.
        """
        if signature and raw_payload:
            await self.provider.verify_webhook(raw_payload, signature)

        payment = await self.payment_repo.get_by_provider_order_id(
            provider_order_id, for_update=True
        )
        if not payment and provider_payment_id:
            payment = await self.payment_repo.get_by_provider_payment_id(
                provider_payment_id, for_update=True
            )
        if not payment:
            raise EntityNotFoundError(
                f"Payment for order ID {provider_order_id} not found."
            )

        if payment.status == PaymentStatus.PAID:
            logger.info(
                "Payment id=%s (order=%s) is already PAID. Idempotent return.",
                payment.id,
                provider_order_id,
            )
            return payment

        if payment.status in (PaymentStatus.REFUNDED, PaymentStatus.CANCELLED, PaymentStatus.FAILED):
            raise PaymentVerificationError(
                f"Payment {payment.id} is in terminal state {payment.status.value}; "
                "refusing to reactivate entitlement from a stale/replayed webhook."
            )

        verification = await self.provider.fetch_payment(provider_payment_id)
        if not verification.is_valid:
            raise PaymentVerificationError(
                f"Payment {provider_payment_id} is not valid or captured on the gateway (status={verification.status})"
            )

        # SECURITY INVARIANT (Finding C-1 defense-in-depth): the amount actually captured at the
        # gateway (fetched live from the provider, not trusted from the webhook payload alone)
        # must match the amount the order was created for. This blocks any scenario where the
        # captured amount was tampered with or diverges from what was originally billed, and
        # ensures a mismatch never results in subscription activation.
        if (
            verification.amount_minor_units is not None
            and verification.amount_minor_units != payment.amount_minor_units
        ):
            logger.warning(
                "Payment amount mismatch detected for payment id=%s (order=%s): "
                "expected=%s captured=%s. Refusing to activate entitlement.",
                payment.id,
                provider_order_id,
                payment.amount_minor_units,
                verification.amount_minor_units,
            )
            raise PaymentVerificationError(
                f"Captured amount for payment {provider_payment_id} does not match the expected order amount."
            )

        try:
            now = datetime.now(timezone.utc)
            payment.provider_payment_id = provider_payment_id
            payment.status = PaymentStatus.PAID
            payment.paid_at = now
            await self.payment_repo.update(payment, commit=False)

            # Entitlement Activation via SubscriptionService
            if payment.subscription_id:
                sub = await self.subscription_repo.get_by_id(
                    payment.subscription_id, for_update=True
                )
                if sub:
                    if sub.status in (
                        SubscriptionLifecycleStatus.ACTIVE,
                        SubscriptionLifecycleStatus.GRACE,
                        SubscriptionLifecycleStatus.TRIAL,
                    ):
                        new_expires_at = max(sub.expires_at, now) + timedelta(days=30)
                        await self.subscription_service.renew_subscription(
                            sub.id, new_expires_at, commit=False
                        )
                    else:
                        await self.subscription_service.activate_subscription(
                            sub.id, commit=False
                        )
                    await self.session.commit()
                    await self.session.refresh(payment)
                    logger.info(
                        "Updated existing subscription id=%s for payment id=%s",
                        sub.id,
                        payment.id,
                    )
                    return payment

            # Look for an existing active subscription for this account
            existing_active = await self.subscription_repo.get_active_for_account(
                payment.account_id, now, for_update=True
            )
            if existing_active:
                new_expires_at = max(existing_active.expires_at, now) + timedelta(
                    days=30
                )
                renewed = await self.subscription_service.renew_subscription(
                    existing_active.id, new_expires_at, commit=False
                )
                payment.subscription_id = renewed.id
                await self.payment_repo.update(payment, commit=False)
                await self.session.commit()
                await self.session.refresh(payment)
                logger.info(
                    "Renewed active subscription id=%s for payment id=%s",
                    renewed.id,
                    payment.id,
                )
                return payment

            # Otherwise, create a new active subscription for the account
            new_sub = await self.subscription_service.create_subscription(
                account_id=payment.account_id,
                plan_id=plan_id,
                starts_at=now,
                expires_at=now + timedelta(days=30),
                status=SubscriptionLifecycleStatus.ACTIVE,
                commit=False,
            )
            payment.subscription_id = new_sub.id
            await self.payment_repo.update(payment, commit=False)
            await self.session.commit()
            await self.session.refresh(payment)
            logger.info(
                "Created and linked new subscription id=%s for payment id=%s",
                new_sub.id,
                payment.id,
            )
            return payment
        except ProvisioningConflictError as exc:
            await self.session.rollback()
            logger.warning("Admin override conflict during payment confirmation: %s", str(exc))
            from app.security_hardening.audit import audit_service
            await audit_service.record_event(
                event_type="admin_override_conflict",
                actor_id=str(payment.account_id),
                target_id=str(payment.id),
                details={"action": "confirm_payment_blocked", "reason": str(exc)},
            )
            raise PaymentVerificationError(f"Payment captured but entitlement activation blocked: {exc}") from exc
        except Exception:
            await self.session.rollback()
            raise

    async def fail_payment(
        self,
        provider_order_id: str,
        reason: str | None = None,
    ) -> Payment:
        """
        Mark a payment as failed after notification from the gateway.
        Idempotent if already marked FAILED or CANCELLED.
        """
        payment = await self.payment_repo.get_by_provider_order_id(
            provider_order_id, for_update=True
        )
        if not payment:
            raise EntityNotFoundError(
                f"Payment for order ID {provider_order_id} not found."
            )

        if payment.status in (
            PaymentStatus.PAID,
            PaymentStatus.REFUNDED,
            PaymentStatus.FAILED,
            PaymentStatus.CANCELLED,
        ):
            return payment

        payment.status = PaymentStatus.FAILED
        await self.payment_repo.update(payment)
        logger.info(
            "Marked payment id=%s as FAILED. Reason: %s",
            payment.id,
            reason or "Gateway notification",
        )
        return payment

    async def refund_payment(
        self,
        payment_id: uuid.UUID,
        amount_minor_units: int | None = None,
        notes: dict[str, str] | None = None,
    ) -> Payment:
        """
        Issue a refund for a paid transaction via the gateway provider.
        """
        payment = await self.payment_repo.get_by_id(payment_id, for_update=True)
        if not payment:
            raise EntityNotFoundError(f"Payment with ID {payment_id} not found.")

        if payment.status != PaymentStatus.PAID:
            raise PaymentRefundError(
                f"Cannot refund payment id={payment_id} in status {payment.status.value}"
            )

        if not payment.provider_payment_id:
            raise PaymentRefundError(
                f"Payment id={payment_id} is missing provider_payment_id"
            )

        try:
            await self.provider.refund_payment(
                provider_payment_id=payment.provider_payment_id,
                amount_minor_units=amount_minor_units or payment.amount_minor_units,
                notes=notes,
            )

            payment.status = PaymentStatus.REFUNDED
            await self.payment_repo.update(payment, commit=False)
            if payment.subscription_id:
                await self.subscription_service.cancel_subscription(
                    payment.subscription_id, commit=False
                )
            await self.session.commit()
            await self.session.refresh(payment)
            logger.info(
                "Refunded payment id=%s amount=%s",
                payment.id,
                amount_minor_units or payment.amount_minor_units,
            )
            return payment
        except Exception:
            await self.session.rollback()
            raise

    async def cancel_payment(
        self,
        payment_id: uuid.UUID,
        *,
        commit: bool = True,
    ) -> Payment:
        """
        Cancel a pending or created payment before capture.
        """
        payment = await self.payment_repo.get_by_id(payment_id, for_update=True)
        if not payment:
            raise EntityNotFoundError(f"Payment with ID {payment_id} not found.")

        if payment.status in (PaymentStatus.PAID, PaymentStatus.REFUNDED):
            raise PaymentServiceError(
                f"Cannot cancel payment id={payment_id} in status {payment.status.value}"
            )

        if payment.status == PaymentStatus.CANCELLED:
            return payment

        payment.status = PaymentStatus.CANCELLED
        await self.payment_repo.update(payment, commit=commit)
        logger.info("Cancelled payment id=%s", payment.id)
        return payment

    async def check_provider_health(self) -> bool:
        """Check health and readiness of the underlying payment gateway provider."""
        return await self.provider.health_check()

    async def get_payment(self, payment_id: uuid.UUID) -> Payment:
        """
        Retrieve payment details by internal UUID.

        """
        payment = await self.payment_repo.get_by_id(payment_id)
        if not payment:
            raise EntityNotFoundError(f"Payment with ID {payment_id} not found.")
        return payment

    async def list_account_payments(
        self, account_id: uuid.UUID, limit: int = 20, offset: int = 0
    ) -> tuple[list[Payment], int]:
        """
        List paginated payment history for an account, newest first.
        Enforces maximum page size of 100.
        """
        limit = min(max(1, limit), 100)
        offset = max(0, offset)
        payments = await self.payment_repo.list_by_account_id_paginated(
            account_id, limit, offset
        )
        total = await self.payment_repo.count_by_account_id(account_id)
        return payments, total

    async def get_account_payment(
        self, account_id: uuid.UUID, payment_identifier: str
    ) -> Payment:
        """
        Retrieve a payment by provider order ID, provider payment ID, or internal UUID.
        Enforces Anti-IDOR: raises EntityNotFoundError (mapped to 404) if payment does not exist
        or belongs to a different account.
        """
        payment = await self.payment_repo.get_by_provider_order_id(payment_identifier)
        if not payment:
            payment = await self.payment_repo.get_by_provider_payment_id(
                payment_identifier
            )
        if not payment:
            try:
                payment_uuid = uuid.UUID(payment_identifier)
                payment = await self.payment_repo.get_by_id(payment_uuid)
            except (ValueError, TypeError, AttributeError):
                pass

        if not payment or payment.account_id != account_id:
            logger.warning(
                "Anti-IDOR: Account %s attempted access or lookup of missing payment identifier %s",
                account_id,
                payment_identifier,
            )
            raise PaymentNotFoundError(f"Payment '{payment_identifier}' not found.")
        return payment

    async def process_webhook(
        self,
        raw_payload: bytes | str,
        signature: str,
    ) -> Payment | None:
        """
        Process an incoming gateway webhook with idempotency guarantees.
        """
        dto = await self.provider.verify_webhook(raw_payload, signature)
        if not dto.provider_order_id:
            raise PaymentWebhookError("Webhook payload missing order ID")

        if dto.event_type in ("payment.captured", "payment.authorized", "order.paid"):
            if not dto.provider_payment_id:
                raise PaymentWebhookError("Payment captured webhook missing payment ID")
            return await self.confirm_payment(
                provider_order_id=dto.provider_order_id,
                provider_payment_id=dto.provider_payment_id,
            )
        elif dto.event_type in ("payment.failed",):
            return await self.fail_payment(
                provider_order_id=dto.provider_order_id,
                reason="Webhook payment.failed event",
            )
        elif dto.event_type in ("refund.processed", "payment.dispute.created", "chargeback"):
            return await self.process_refund_webhook(
                provider_order_id=dto.provider_order_id,
                provider_payment_id=dto.provider_payment_id,
                reason=dto.event_type,
            )

        logger.info("Ignored unhandled webhook event type: %s", dto.event_type)
        return None

    async def process_refund_webhook(
        self,
        provider_order_id: str | None = None,
        provider_payment_id: str | None = None,
        reason: str | None = None,
    ) -> Payment:
        """
        Process a refund.processed or dispute webhook event from the gateway.
        Idempotent: if payment is already REFUNDED, returns cleanly.
        """
        if provider_order_id:
            payment = await self.payment_repo.get_by_provider_order_id(
                provider_order_id, for_update=True
            )
        elif provider_payment_id:
            payment = await self.payment_repo.get_by_provider_payment_id(
                provider_payment_id, for_update=True
            )
        else:
            raise PaymentWebhookError(
                "Refund webhook missing both order_id and payment_id"
            )

        if not payment:
            raise EntityNotFoundError(
                f"Payment not found for refund webhook order={provider_order_id} payment={provider_payment_id}"
            )

        if payment.status == PaymentStatus.REFUNDED:
            logger.info(
                "Payment id=%s is already REFUNDED. Idempotent return.", payment.id
            )
            return payment

        # Determine if it's a partial refund or full refund/chargeback
        is_chargeback = False
        if reason and ("dispute" in reason or "chargeback" in reason):
            is_chargeback = True
            
        is_partial = False
        if not is_chargeback and payment.provider_payment_id:
            verification = await self.provider.fetch_payment(payment.provider_payment_id)
            if verification.amount_refunded_minor_units > 0 and verification.amount_refunded_minor_units < payment.amount_minor_units:
                is_partial = True

        try:
            if is_partial:
                payment.status = PaymentStatus.PARTIALLY_REFUNDED
                await self.payment_repo.update(payment, commit=False)
                # We do NOT cancel the subscription for a partial refund.
                logger.info("Processed PARTIAL refund webhook for payment id=%s", payment.id)
            else:
                payment.status = PaymentStatus.REFUNDED
                await self.payment_repo.update(payment, commit=False)
                if payment.subscription_id:
                    await self.subscription_service.cancel_subscription(
                        payment.subscription_id, commit=False
                    )
                logger.info("Processed FULL refund/chargeback webhook for payment id=%s (reason=%s)", payment.id, reason)
                
            await self.session.commit()
            await self.session.refresh(payment)
            return payment
        except Exception:
            await self.session.rollback()
            raise
