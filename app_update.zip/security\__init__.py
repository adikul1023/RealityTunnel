"""
RealityTunnel Security & Cryptographic Utilities

Shared cryptographic functions, token generators, and constants.
Strictly independent from FastAPI, SQLAlchemy, Alembic, Repositories, and JWT.
"""

from app.security.constants import (
    MASTER_TOKEN_BYTES,
    REFRESH_TOKEN_BYTES,
    REFRESH_TOKEN_EXPIRE_DAYS,
    DEVICE_GUID_BYTES,
    SHA256_HEX_LENGTH,
    ACCOUNT_ID_PREFIX,
    ACCOUNT_ID_GROUPS,
    ACCOUNT_ID_GROUP_SIZE,
    ACCOUNT_ID_SEPARATOR,
    ACCOUNT_ID_ALPHABET,
)
from app.security.crypto import (
    hash_master_token,
    compare_secrets,
    verify_master_token,
    hash_refresh_token,
    verify_refresh_token_hash,
)
from app.security.tokens import (
    generate_master_token,
    generate_refresh_token,
    generate_device_guid,
    generate_account_id,
)
from app.security.jwt_models import (
    AccessTokenClaims,
    ACCESS_TOKEN_EXPIRE_MINUTES,
    JWT_ALGORITHM,
    JWT_ISSUER,
    JWT_AUDIENCE,
)
from app.security.jwt_service import JWTService
from app.security.admin_password import AdminPasswordService
from app.security.admin_jwt import AdminJWTService, AdminTokenClaims

__all__ = [
    "MASTER_TOKEN_BYTES",
    "REFRESH_TOKEN_BYTES",
    "REFRESH_TOKEN_EXPIRE_DAYS",
    "DEVICE_GUID_BYTES",
    "SHA256_HEX_LENGTH",
    "ACCOUNT_ID_PREFIX",
    "ACCOUNT_ID_GROUPS",
    "ACCOUNT_ID_GROUP_SIZE",
    "ACCOUNT_ID_SEPARATOR",
    "ACCOUNT_ID_ALPHABET",
    "hash_master_token",
    "compare_secrets",
    "verify_master_token",
    "hash_refresh_token",
    "verify_refresh_token_hash",
    "generate_master_token",
    "generate_refresh_token",
    "generate_device_guid",
    "generate_account_id",
    "AccessTokenClaims",
    "ACCESS_TOKEN_EXPIRE_MINUTES",
    "JWT_ALGORITHM",
    "JWT_ISSUER",
    "JWT_AUDIENCE",
    "JWTService",
    "AdminPasswordService",
    "AdminJWTService",
    "AdminTokenClaims",
]
